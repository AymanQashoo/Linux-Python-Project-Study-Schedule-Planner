import queue

class Course1():

    def __init__(self, name, count_prerequisites, cridit):
        self.name = name
        self.count_prerequisites = count_prerequisites
        self.cridit = cridit
    queue = queue.Queue()

#def PRIO(self):